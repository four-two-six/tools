在 mybatis-generator-core-1.3.7 目录下执行
java -jar ./lib/mybatis-generator-core-1.3.7.jar -configfile ./generatorConfig.xml -overwrite